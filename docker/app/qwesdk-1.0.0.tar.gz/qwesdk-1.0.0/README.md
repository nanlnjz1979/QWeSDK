# QWeSDK
Quantitative SDK, Backtesting, Paper Trading Interface